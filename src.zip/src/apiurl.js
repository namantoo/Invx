const Apiurl = () => {
    const apiu = "http://159.223.34.11:5000";
    // const apiu = "http://13.235.79.115";
    return (apiu);
}

export default Apiurl;

import { ConnectButton } from '@rainbow-me/rainbowkit';

const RainbowConnect = () => {
  return (
    <div className='p-8'>
      <ConnectButton />
    </div>
  );
};

export default RainbowConnect;